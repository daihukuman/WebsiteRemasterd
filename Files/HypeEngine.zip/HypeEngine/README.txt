このテキストファイルでは、追加されているLuaの関数について説明します。引数の例に型を書いていますが、Luaでは書く必要はありません。
ちなみにエンジンの特性上、改造がすごく簡単なゲームになります。ごめん

UseIt(...)
ファイルをメモリに読み込みます。引数の中に使用する画像または音声ファイルのパスを入れます。Engine.exeからの相対パスです。決してループの中で使うなんてことはしないでください。
また、その後DrawImageやPlaySoundHandleなどで扱う際は、ファイルの名前を引数に入力してください。(例：Useitでresources/Image/PlaceHolder.pngをロードした場合、DrawImageでPlaceHolder.pngとして表記する)

Escape()
UseIt()で読み込まれたファイルのメモリを解放します。基本的にすべてを解放します。特定の画像/音声だけ解放することはできません。

DrawString(int x, int y, string text)
画面にテキストを表示します。一番目と二番目の引数は座標です。textの中に表示したい文字を入れます。

KeyCheck(int key)
キーが押されているかどうかを判定します。keyには、KEY_ZやKEY_Wと入力すると置き換えられるようになっています。押された瞬間を検知する関数はないので、そこはLua側で実装してください。

DrawImage(int x, int y, string FileName)
xとyには座標を入れます。FileNameにはファイルの名前を入れてください。詳しくは6行目まで…

PlaySoundHandle(string FileName, int PlayType)
FileNameにはファイルの名前を入れてください。詳しくは6行目まで…
PlayTypeについて：
再生したい方法別で表記してください。

PLAY_LOOP  ループ再生
PLAY_BACK  バックグラウンド再生
PLAY_NORMAL  ノーマル再生(再生している間プログラムが止まります)

--------フック関数--------

function THINK_HOOK
この関数を定義することで、中のコードを毎フレーム実行します。

--------その他--------

・Engine.exeの名前は自由に変えることができます。
・このエンジンは残念なことにまだPREPREPREPREPREPREPREPREPREPREPREPREPREPREALPHA版です。私がこのエンジンに飽きるまでに完成することを祈っていなさい
・このエンジンはMITライセンスです。LICENSE.txtの-libraryより上を消して、このエンジンを使ったことを表記してください。

This software uses Inaba engine.
Copyright (c) 2020 Inaba



