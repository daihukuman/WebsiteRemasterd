print("Hello world!") 
